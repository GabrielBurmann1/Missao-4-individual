/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject2;

/**
 *
 * @author Usuario
 */
public class Mavenproject2 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
